﻿Public Class Form2

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("Güvenlik Kodu Doğrulandı !", MsgBoxStyle.Information, "Bilgi")
        Dim content1_txtInput As HtmlElement = WebBrowser1.Document.GetElementById("content1_txtInput")
        Dim content1_lblResults As HtmlElement = WebBrowser1.Document.GetElementById("content1_lblResults")
        Dim content1_txtCaptcha As HtmlElement = WebBrowser1.Document.GetElementById("content1_txtCaptcha")
        Dim content1_btnSubmit As HtmlElement = WebBrowser1.Document.GetElementById("content1_btnSubmit")



        content1_txtInput.SetAttribute("value", TextBox1.Text)
        content1_lblResults.SetAttribute("value", TextBox2.Text)
        content1_txtCaptcha.SetAttribute("value", TextBox3.Text)
        content1_btnSubmit.InvokeMember("click")
        Dim bilgi As HtmlElementCollection = WebBrowser1.Document.All
        For Each element As HtmlElement In bilgi
            If element.GetAttribute("classname").Contains("results") Then
                TextBox2.Text = element.InnerText
            End If
        Next

    End Sub

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted

        On Error Resume Next
        Dim Nesne As Object
        Nesne = WebBrowser1.Document.DomDocument.body.createControlRange()
        Call Nesne.Add(WebBrowser1.Document.Images("content1_imgCaptcha").DomElement)
        Call Nesne.execCommand("Copy")
        PictureBox1.Image = My.Computer.Clipboard.GetImage()
        Dim bilgi As HtmlElementCollection = WebBrowser1.Document.All
        For Each element As HtmlElement In bilgi
            If element.GetAttribute("classname").Contains("results") Then
                TextBox2.Text = element.InnerText
            End If
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim content1_txtInput As HtmlElement = WebBrowser1.Document.GetElementById("content1_txtInput")
        Dim content1_lblResults As HtmlElement = WebBrowser1.Document.GetElementById("content1_lblResults")
        Dim content1_txtCaptcha As HtmlElement = WebBrowser1.Document.GetElementById("content1_txtCaptcha")
        Dim content1_btnSubmit As HtmlElement = WebBrowser1.Document.GetElementById("content1_btnSubmit")



        content1_txtInput.SetAttribute("value", TextBox1.Text)
        content1_lblResults.SetAttribute("value", TextBox2.Text)
        content1_txtCaptcha.SetAttribute("value", TextBox3.Text)
        content1_btnSubmit.InvokeMember("click")
        Dim bilgi As HtmlElementCollection = WebBrowser1.Document.All
        For Each element As HtmlElement In bilgi
            If element.GetAttribute("classname").Contains("results") Then
                TextBox2.Text = element.InnerText
            End If
        Next
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
